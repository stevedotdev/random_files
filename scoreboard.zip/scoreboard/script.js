const score1 = document.getElementById("score1");
const score2 = document.getElementById("score2");
const timeDisplay = document.getElementById("time");
const halfDisplay = document.getElementById("half");

let minutes = 0;
let seconds = 0;
let interval = null;
let half = 1;

function updateTime() {
  seconds++;
  if (seconds >= 60) {
    minutes++;
    seconds = 0;
  }
  if (minutes >= 45) {
    if (half === 1) {
      half = 2;
      minutes = 0;
      seconds = 0;
      halfDisplay.textContent = "Second Half";
    }
  }
  timeDisplay.textContent = `${String(minutes).padStart(2, "0")}:${String(
    seconds
  ).padStart(2, "0")}`;
}

function startGame() {
  if (!interval) {
    interval = setInterval(updateTime, 1000);
  }
}

window.onload = startGame;

function updateScore(team, points) {
  if (team === 1) {
    score1.textContent = parseInt(score1.textContent) + points;
  } else if (team === 2) {
    score2.textContent = parseInt(score2.textContent) + points;
  }
}
