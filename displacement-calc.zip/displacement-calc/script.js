function toggleMode() {
  const mode = document.getElementById("mode").value;
  if (mode === "constantVelocity") {
    document.getElementById("accelerationLabel").style.display = "none";
    document.getElementById("acceleration").style.display = "none";
  } else {
    document.getElementById("accelerationLabel").style.display = "block";
    document.getElementById("acceleration").style.display = "block";
  }
}

function calculateDisplacement() {
  const mode = document.getElementById("mode").value;
  const initialVelocity = parseFloat(
    document.getElementById("initialVelocity").value
  );
  const time = parseFloat(document.getElementById("time").value);

  let displacement;
  if (mode === "constantVelocity") {
    displacement = initialVelocity * time;
  } else {
    const acceleration = parseFloat(
      document.getElementById("acceleration").value
    );
    displacement = initialVelocity * time + 0.5 * acceleration * time * time;
  }

  document.getElementById(
    "result"
  ).innerText = `Displacement: ${displacement} meters`;
}

// Initialize to hide acceleration inputs on page load
toggleMode();
