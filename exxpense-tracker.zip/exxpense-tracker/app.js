document
  .getElementById("expense-form")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    // Get the expense details from the form
    const date = document.getElementById("date").value;
    const category = document.getElementById("category").value;
    const amount = parseFloat(document.getElementById("amount").value);

    // Create a new row for the expense
    const newRow = document.createElement("tr");
    newRow.innerHTML = `
        <td>${date}</td>
        <td>${category}</td>
        <td>$${amount.toFixed(2)}</td>
    `;

    // Add the new row to the table
    document.getElementById("expenses-list").appendChild(newRow);

    // Update the total expenses
    const total = parseFloat(
      document.getElementById("total-expenses").textContent
    );
    document.getElementById("total-expenses").textContent = (
      total + amount
    ).toFixed(2);

    // Reset the form
    document.getElementById("expense-form").reset();

    // Change the color of the add expense button
    changeButtonColor();
  });

// Function to change button color
function changeButtonColor() {
  const colors = [
    "#34495e",
    "#2c3e50",
    "#233746",
    "#212f3d",
    "#1b2631",
    "#17202a",
  ];
  const button = document.getElementById("add-expense-btn");

  // Get the current color index
  const currentColor = button.style.backgroundColor;
  let index = colors.indexOf(currentColor) + 1;

  // Loop back to the first color if we've reached the end of the array
  if (index >= colors.length || index < 0) {
    index = 0;
  }

  // Set the new button color
  button.style.backgroundColor = colors[index];
}
